#include <iostream>
#include "Menu.h"

int main() {
 Menu menu;
  menu.mainmenu();
}